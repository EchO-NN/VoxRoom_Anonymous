"""Perception adapters."""
