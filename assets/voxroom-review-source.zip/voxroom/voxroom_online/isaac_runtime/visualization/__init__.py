"""Debug visualization helpers."""
