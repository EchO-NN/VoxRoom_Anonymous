"""Sensor geometry utilities."""
