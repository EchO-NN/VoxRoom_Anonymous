"""Offline snapshot replay baselines."""
